#ifdef __cplusplus
extern "C"{
#endif

extern float testInput_f32[TEST_LENGTH_SAMPLES];
extern float lmsNormCoeff_f32[32];
extern const float FIRCoeff_f32[32];

#ifdef __cplusplus
} // extern "C"
#endif
